"""
Main entry point for the MongoDB version of the application
"""
from app_mongo import app, init_db
import routes_mongo
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    logger.info("Starting application with MongoDB backend")
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)