"""
Flask application configuration with MongoDB
"""
import os
import logging
from flask import Flask
from flask_login import LoginManager, UserMixin
from werkzeug.middleware.proxy_fix import ProxyFix
from bson import ObjectId
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "your_secret_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Setup Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Import MongoDB models
from db_mongo import User as MongoUser, UserPreference, Portfolio, Stock, StockHistory, PortfolioItem, News, Recommendation

# Create Flask-Login User class that works with MongoDB User
class User(UserMixin):
    def __init__(self, user_dict):
        self.user_dict = user_dict
        self.id = str(user_dict.get('_id', ''))
        self.username = user_dict.get('username', '')
        self.email = user_dict.get('email', '')
        self.password_hash = user_dict.get('password_hash', '')
        self.created_at = user_dict.get('created_at')
    
    def get_id(self):
        return self.id
    
    @property
    def preferences(self):
        prefs = UserPreference.find_by_user_id(self.id)
        return prefs
    
    @property
    def portfolios(self):
        portfolios = Portfolio.find_by_user_id(self.id)
        return portfolios

@login_manager.user_loader
def load_user(user_id):
    user_dict = MongoUser.find_by_id(user_id)
    if not user_dict:
        return None
    return User(user_dict)

# Initialize database
def init_db():
    """Initialize database with basic settings"""
    logger.info("Database initialized")