"""
Recommendation system for MongoDB version
"""
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
from bson import ObjectId

from db_mongo import (
    UserPreference, Stock, StockHistory,
    Portfolio, PortfolioItem, Recommendation
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_recommendations(user_id):
    """
    Generate stock recommendations for a user based on their preferences and portfolio
    
    Args:
        user_id (str or ObjectId): User ID to generate recommendations for
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Convert str to ObjectId if needed
        if isinstance(user_id, str):
            user_id = ObjectId(user_id)
        
        # Get user preferences
        user_prefs = UserPreference.find_by_user_id(user_id)
        
        if not user_prefs:
            logger.error(f"No preferences found for user {user_id}")
            return False
        
        # Get user's current portfolio
        portfolios = Portfolio.find_by_user_id(user_id)
        portfolio_stocks = []
        
        if portfolios:
            portfolio = portfolios[0]
            portfolio_id = portfolio.get('_id')
            
            # Get all items in the portfolio
            items = PortfolioItem.find_by_portfolio_id(portfolio_id)
            portfolio_stocks = [item.get('stock_id') for item in items]
        
        # Get all stocks from the database
        all_stocks = Stock.find_all({})
        
        if not all_stocks:
            logger.error("No stocks found in database")
            return False
        
        # Prepare data for recommendation algorithm
        stocks_data = []
        
        for stock in all_stocks:
            stock_id = stock.get('_id')
            
            # Skip stocks already in portfolio
            if stock_id in portfolio_stocks:
                continue
            
            # Use fixed volatility based on sector for testing
            sector_volatility = {
                'Technology': 0.3,
                'Healthcare': 0.2,
                'Financial Services': 0.25,
                'Consumer Goods': 0.15,
                'Energy': 0.35,
                'Utilities': 0.1,
                'Industrials': 0.2,
                'Materials': 0.25,
                'Real Estate': 0.2,
                'Telecommunications': 0.15,
                'Automotive': 0.4,
                'Entertainment': 0.3,
                'Retail': 0.25
            }
            
            sector = stock.get('sector')
            volatility = sector_volatility.get(sector, 0.2) if sector else 0.2
            
            # Get historical data if available
            end_date = datetime.now().date()
            start_date = end_date - timedelta(days=30)
            
            history = StockHistory.find_by_stock_id_and_date_range(stock_id, start_date, end_date)
            
            # Calculate average volume from historical data
            avg_volume = 0
            if history:
                volumes = [h.get('volume', 0) for h in history]
                avg_volume = sum(volumes) / len(volumes) if volumes else 0
            else:
                # Estimate volume based on price if no history
                avg_volume = stock.get('current_price', 0) * 10000 if stock.get('current_price') else 500000
            
            # Create feature vector for the stock
            stock_data = {
                'id': stock_id,
                'symbol': stock.get('symbol'),
                'name': stock.get('name'),
                'sector': sector or 'Unknown',
                'market': stock.get('market') or 'Unknown',
                'price': stock.get('current_price', 0),
                'volatility': volatility,
                'avg_volume': avg_volume
            }
            
            stocks_data.append(stock_data)
        
        if not stocks_data:
            logger.error("No valid stock data for recommendations")
            return False
        
        # Convert to DataFrame
        stocks_df = pd.DataFrame(stocks_data)
        
        # One-hot encode categorical variables
        sectors = pd.get_dummies(stocks_df['sector'], prefix='sector')
        markets = pd.get_dummies(stocks_df['market'], prefix='market')
        
        # Create feature matrix
        feature_cols = ['price', 'volatility', 'avg_volume']
        X = pd.concat([stocks_df[feature_cols], sectors, markets], axis=1)
        
        # Normalize features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Create user preference vector
        feature_columns = list(X.columns)
        user_vector = create_user_preference_vector(user_prefs, feature_columns)
        
        # Reshape user vector for similarity calculation
        user_vector = np.array(user_vector).reshape(1, -1)
        
        # Calculate similarity scores
        similarity_scores = cosine_similarity(X_scaled, user_vector).flatten()
        
        # Add scores to stocks_data
        for i, score in enumerate(similarity_scores):
            stocks_data[i]['score'] = float(score)
        
        # Sort by score
        stocks_data = sorted(stocks_data, key=lambda x: x['score'], reverse=True)
        
        # Clear previous recommendations
        Recommendation.delete_by_user_id(user_id)
        
        # Store top recommendations
        for stock_data in stocks_data[:10]:  # Store top 10 recommendations
            reason = generate_recommendation_reason(stock_data, user_prefs)
            
            Recommendation.create(
                user_id=user_id,
                stock_id=stock_data['id'],
                score=stock_data['score'],
                reason=reason
            )
        
        logger.info(f"Generated {len(stocks_data[:10])} recommendations for user {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"Error generating recommendations: {e}")
        return False

def create_user_preference_vector(user_prefs, feature_columns):
    """
    Create a feature vector representing user preferences
    
    Args:
        user_prefs (dict): User preference object
        feature_columns (list): List of column names in feature matrix
    
    Returns:
        list: User preference vector matching feature columns
    """
    user_vector = [0] * len(feature_columns)
    
    # Set risk tolerance (affects volatility weight)
    risk_weight = 0.0
    if user_prefs.get('risk_tolerance') == 'low':
        risk_weight = -1.0  # Prefer low volatility
    elif user_prefs.get('risk_tolerance') == 'medium':
        risk_weight = 0.0   # Neutral on volatility
    elif user_prefs.get('risk_tolerance') == 'high':
        risk_weight = 1.0   # Prefer high volatility
    
    # Set investment horizon (affects price weight)
    price_weight = 0.0
    if user_prefs.get('investment_horizon') == 'short':
        price_weight = -0.5  # Less emphasis on price
    elif user_prefs.get('investment_horizon') == 'medium':
        price_weight = 0.0   # Neutral on price
    elif user_prefs.get('investment_horizon') == 'long':
        price_weight = 0.5   # More emphasis on price
    
    # Set preferred sectors
    preferred_sectors = user_prefs.get('preferred_sectors') or []
    
    # Set preferred markets
    preferred_markets = user_prefs.get('preferred_markets') or []
    
    # Apply preferences to vector
    for i, col in enumerate(feature_columns):
        if col == 'volatility':
            user_vector[i] = risk_weight
        elif col == 'price':
            user_vector[i] = price_weight
        elif col == 'avg_volume':
            user_vector[i] = 0.5  # Generally prefer higher volume (more liquid)
        elif col.startswith('sector_'):
            sector = col.replace('sector_', '')
            if sector in preferred_sectors:
                user_vector[i] = 1.0
        elif col.startswith('market_'):
            market = col.replace('market_', '')
            if market in preferred_markets:
                user_vector[i] = 1.0
    
    return user_vector

def generate_recommendation_reason(stock_data, user_prefs):
    """
    Generate a human-readable reason for the recommendation
    
    Args:
        stock_data (dict): Stock data with features
        user_prefs (dict): User preference object
    
    Returns:
        str: Recommendation reason
    """
    reasons = []
    
    # Add sector-based reason if it matches user preference
    sector = stock_data.get('sector')
    preferred_sectors = user_prefs.get('preferred_sectors') or []
    
    if sector in preferred_sectors:
        reasons.append(f"Matches your interest in {sector} sector")
    
    # Add market-based reason if it matches user preference
    market = stock_data.get('market')
    preferred_markets = user_prefs.get('preferred_markets') or []
    
    if market in preferred_markets:
        reasons.append(f"Aligns with your preference for {market} markets")
    
    # Add risk-based reason
    risk_tolerance = user_prefs.get('risk_tolerance')
    volatility = stock_data.get('volatility', 0)
    
    if risk_tolerance == 'low' and volatility < 0.2:
        reasons.append("Lower volatility suitable for conservative investors")
    elif risk_tolerance == 'high' and volatility > 0.3:
        reasons.append("Higher volatility with potential for greater returns")
    elif risk_tolerance == 'medium' and 0.15 <= volatility <= 0.3:
        reasons.append("Moderate volatility aligned with your risk profile")
    
    # Add investment horizon reason
    investment_horizon = user_prefs.get('investment_horizon')
    
    if investment_horizon == 'long':
        reasons.append("Good potential for long-term growth")
    elif investment_horizon == 'medium':
        reasons.append("Balanced performance for medium-term investment")
    elif investment_horizon == 'short':
        reasons.append("Suitable for short-term investment strategy")
    
    # If no specific reasons, add a generic one based on score
    if not reasons:
        score = stock_data.get('score', 0)
        if score > 0.8:
            reasons.append("Strong overall match with your investment profile")
        elif score > 0.6:
            reasons.append("Good match with your investment criteria")
        else:
            reasons.append("Moderate fit for your investment preferences")
    
    return ". ".join(reasons) + "."

def calculate_portfolio_performance(portfolio_id):
    """
    Calculate performance metrics for a portfolio
    
    Args:
        portfolio_id (ObjectId or str): Portfolio ID
    
    Returns:
        dict: Performance metrics
    """
    try:
        # Convert string ID to ObjectId if needed
        if isinstance(portfolio_id, str):
            portfolio_id = ObjectId(portfolio_id)
        
        # Get portfolio items
        portfolio_items = PortfolioItem.find_by_portfolio_id(portfolio_id)
        
        if not portfolio_items:
            return {
                'total_value': 0,
                'total_cost': 0,
                'total_return': 0,
                'total_return_percent': 0,
                'performance_timeline': []
            }
        
        # Calculate current values
        total_current_value = 0
        total_cost = 0
        
        for item in portfolio_items:
            stock_id = item.get('stock_id')
            stock = Stock.find_by_id(stock_id)
            
            if stock:
                current_price = stock.get('current_price', 0)
                quantity = item.get('quantity', 0)
                purchase_price = item.get('purchase_price', 0)
                
                current_value = current_price * quantity
                cost_basis = purchase_price * quantity
                
                total_current_value += current_value
                total_cost += cost_basis
        
        # Calculate total return
        total_return = total_current_value - total_cost
        total_return_percent = (total_return / total_cost) * 100 if total_cost > 0 else 0
        
        # Calculate historical performance (only 7 data points for the past month)
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=30)
        
        performance_timeline = []
        
        # Use exactly 7 data points (weekly) for consistency
        data_points = 7
        day_interval = max(1, 30 // (data_points - 1))  # Ensure positive interval
        
        # Only use up to 7 data points to prevent chart expansion
        sample_days = [i for i in range(0, 31, day_interval)][:7]  # Limit to 7 points
        
        for i in sample_days:
            day = end_date - timedelta(days=i)
            day_value = 0
            
            for item in portfolio_items:
                stock_id = item.get('stock_id')
                quantity = item.get('quantity', 0)
                
                # Find the closest historical data point for this day
                history = StockHistory.find_all(
                    {"stock_id": stock_id, "date": {"$lte": day}},
                    sort=[("date", -1)],
                    limit=1
                )
                
                if history:
                    day_value += history[0].get('close_price', 0) * quantity
            
            performance_timeline.append({
                'date': day.strftime('%Y-%m-%d'),
                'value': day_value
            })
        
        # Reverse to get chronological order
        performance_timeline.reverse()
        
        return {
            'total_value': total_current_value,
            'total_cost': total_cost,
            'total_return': total_return,
            'total_return_percent': total_return_percent,
            'performance_timeline': performance_timeline
        }
    
    except Exception as e:
        logger.error(f"Error calculating portfolio performance: {e}")
        return {
            'error': str(e),
            'total_value': 0,
            'total_cost': 0,
            'total_return': 0,
            'total_return_percent': 0,
            'performance_timeline': []
        }