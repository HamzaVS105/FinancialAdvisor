"""
Module for fetching historical stock data from Yahoo Finance
"""
import os
import logging
import datetime
from typing import Dict, List, Optional, Union, Any
import yfinance as yf
import pandas as pd
from bson import ObjectId

from db_mongo import Stock, StockHistory

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def fetch_historical_data(symbol: str, period: str = "1y") -> pd.DataFrame:
    """
    Fetch historical stock data for a given symbol.
    
    Args:
        symbol (str): Stock ticker symbol
        period (str): Period of historical data (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
        
    Returns:
        pd.DataFrame: DataFrame containing historical data
    """
    try:
        ticker = yf.Ticker(symbol)
        hist = ticker.history(period=period)
        
        if hist.empty:
            logger.warning(f"No historical data available for {symbol}")
            return pd.DataFrame()
        
        # Reset index to make date a column
        hist = hist.reset_index()
        
        # Convert Date column to datetime if it's not already
        if not pd.api.types.is_datetime64_any_dtype(hist['Date']):
            hist['Date'] = pd.to_datetime(hist['Date'])
        
        # Keep only needed columns and rename
        hist = hist[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
        hist.columns = ['date', 'open_price', 'high_price', 'low_price', 'close_price', 'volume']
        
        # Convert date to date object
        hist['date'] = hist['date'].dt.date
        
        return hist
    except Exception as e:
        logger.error(f"Error fetching historical data for {symbol}: {e}")
        return pd.DataFrame()

def store_historical_data(symbol: str, period: str = "1y") -> bool:
    """
    Fetch and store historical data for a given stock symbol.
    
    Args:
        symbol (str): Stock ticker symbol
        period (str): Period of historical data
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Find stock in database
        stock = Stock.find_by_symbol(symbol)
        
        if not stock:
            logger.warning(f"Stock {symbol} not found in database")
            return False
        
        stock_id = stock.get('_id')
        
        # Fetch historical data
        hist_df = fetch_historical_data(symbol, period)
        
        if hist_df.empty:
            logger.warning(f"No historical data fetched for {symbol}")
            return False
        
        # Store each data point
        count = 0
        for _, row in hist_df.iterrows():
            # Check if this data point already exists
            existing = StockHistory.find_one({
                "stock_id": stock_id,
                "date": row['date']
            })
            
            if not existing:
                StockHistory.create(
                    stock_id=stock_id,
                    date=row['date'],
                    open_price=float(row['open_price']),
                    high_price=float(row['high_price']),
                    low_price=float(row['low_price']),
                    close_price=float(row['close_price']),
                    volume=int(row['volume'])
                )
                count += 1
            
        logger.info(f"Stored {count} new historical data points for {symbol}")
        
        # Update current price
        if not hist_df.empty:
            latest_price = float(hist_df.iloc[-1]['close_price'])
            Stock.update_price(stock_id, latest_price)
            logger.info(f"Updated current price for {symbol}: {latest_price}")
        
        return True
    except Exception as e:
        logger.error(f"Error storing historical data for {symbol}: {e}")
        return False

def store_multiple_stocks_history(symbols: List[str], period: str = "1y") -> Dict[str, bool]:
    """
    Fetch and store historical data for multiple stock symbols.
    
    Args:
        symbols (List[str]): List of stock ticker symbols
        period (str): Period of historical data
        
    Returns:
        Dict[str, bool]: Dictionary mapping symbols to success status
    """
    results = {}
    
    for symbol in symbols:
        success = store_historical_data(symbol, period)
        results[symbol] = success
    
    return results

def get_all_stocks_and_update_history(period: str = "1y") -> Dict[str, bool]:
    """
    Update historical data for all stocks in the database.
    
    Args:
        period (str): Period of historical data
        
    Returns:
        Dict[str, bool]: Dictionary mapping symbols to success status
    """
    all_stocks = Stock.find_all({})
    results = {}
    
    for stock in all_stocks:
        symbol = stock.get('symbol')
        if symbol:
            success = store_historical_data(symbol, period)
            results[symbol] = success
    
    return results

if __name__ == "__main__":
    # Example usage
    symbol = "AAPL"
    success = store_historical_data(symbol)
    print(f"Stored historical data for {symbol}: {'Success' if success else 'Failed'}")